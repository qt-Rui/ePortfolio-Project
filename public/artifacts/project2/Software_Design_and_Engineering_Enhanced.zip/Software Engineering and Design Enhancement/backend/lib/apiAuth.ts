// inventory-backend/lib/apiAuth.ts
import { NextRequest, NextResponse } from 'next/server';
import { verifyToken } from './auth';

export function getAuthUser(req: NextRequest) {
  const authHeader = req.headers.get('authorization');
  if (!authHeader) return null;

  const [scheme, token] = authHeader.split(' ');
  if (scheme !== 'Bearer' || !token) return null;

  return verifyToken(token);
}

export function requireAuth(req: NextRequest) {
  const user = getAuthUser(req);
  if (!user) {
    return { user: null as any, errorResponse: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) };
  }
  return { user, errorResponse: null as NextResponse | null };
}
