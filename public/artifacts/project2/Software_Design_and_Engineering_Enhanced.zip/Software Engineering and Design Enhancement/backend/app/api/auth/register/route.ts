import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { hashPassword, signToken } from '@/lib/auth';

export async function POST(req: Request) {
  try {
    const { username, password } = await req.json();

    if (!username || !password) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
    }

    // Check if user exists
    const existing = await prisma.user.findUnique({ where: { username } });
    if (existing) {
      return NextResponse.json({ error: 'User already exists' }, { status: 400 });
    }

    // Create user
    const hashed = await hashPassword(password);
    const user = await prisma.user.create({
      data: { username, password: hashed },
    });

    const token = signToken({ userId: user.id, username });

    return NextResponse.json({ token, user }, { status: 201 });

  } catch (e) {
    console.error('REGISTER ERROR:', e);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
