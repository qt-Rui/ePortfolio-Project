import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/apiAuth';

interface Params { params: { id: string } }

export async function PATCH(req: NextRequest, { params }: Params) {
  const { user, errorResponse } = requireAuth(req);
  if (errorResponse) return errorResponse;

  const itemId = Number(params.id);
  if (Number.isNaN(itemId)) {
    return NextResponse.json({ error: 'Invalid ID' }, { status: 400 });
  }

  const existing = await prisma.item.findFirst({
    where: { id: itemId, userId: user.userId },
  });

  if (!existing) {
    return NextResponse.json({ error: 'Item not found' }, { status: 404 });
  }

  const { name, description, quantity } = await req.json();

  const updated = await prisma.item.update({
    where: { id: itemId },
    data: {
      name: name ?? existing.name,
      description: description ?? existing.description,
      quantity: typeof quantity === 'number' ? quantity : existing.quantity,
    },
  });

  return NextResponse.json({ updated });
}

export async function DELETE(req: NextRequest, { params }: Params) {
  const { user, errorResponse } = requireAuth(req);
  if (errorResponse) return errorResponse;

  const itemId = Number(params.id);
  if (Number.isNaN(itemId)) {
    return NextResponse.json({ error: 'Invalid ID' }, { status: 400 });
  }

  const existing = await prisma.item.findFirst({
    where: { id: itemId, userId: user.userId },
  });

  if (!existing) {
    return NextResponse.json({ error: 'Item not found' }, { status: 404 });
  }

  await prisma.item.delete({ where: { id: itemId } });

  return NextResponse.json({ success: true });
}
