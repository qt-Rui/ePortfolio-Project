// src/screens/InventoryScreen.tsx
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../App';
import { apiRequest } from '../api';
import { getAuth, clearAuth } from '../storage';
import { colors } from '../theme';

type Item = {
  id: number;
  name: string;
  description?: string | null;
  quantity: number;
  dateAdded: string;
};

type Props = NativeStackScreenProps<RootStackParamList, 'Inventory'>;

export default function InventoryScreen({ navigation }: Props) {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(false);

  // Modal State
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState<Item | null>(null);
  const [tempName, setTempName] = useState('');
  const [tempQty, setTempQty] = useState(0);
  const [tempDescription, setTempDescription] = useState('');

  async function loadItems() {
    setLoading(true);
    try {
      const { token } = await getAuth();
      const data = await apiRequest('/api/items', {}, token);
      setItems(data.items);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to load inventory');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadItems();
  }, []);

  // ----------------- UI Actions -----------------

  function startAdd() {
    setEditingItem(null);
    setTempName('');
    setTempQty(0);
    setTempDescription('');
    setShowForm(true);
  }

  function startEdit(item: Item) {
    setEditingItem(item);
    setTempName(item.name);
    setTempQty(item.quantity);
    setTempDescription(item.description || '');
    setShowForm(true);
  }

  async function saveItem() {
    const { token } = await getAuth();

    const payload = {
      name: tempName,
      quantity: tempQty,
      description: tempDescription,
    };

    try {
      if (editingItem) {
        await apiRequest(
          `/api/items/${editingItem.id}`,
          {
            method: 'PATCH',
            body: JSON.stringify(payload),
          },
          token
        );
      } else {
        await apiRequest(
          `/api/items`,
          {
            method: 'POST',
            body: JSON.stringify(payload),
          },
          token
        );
      }

      setShowForm(false);
      loadItems();
    } catch (e: any) {
      Alert.alert('Error', e.message);
    }
  }

  async function deleteItem(id: number) {
    const { token } = await getAuth();

    Alert.alert('Confirm', 'Delete this item?', [
      { text: 'Cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          await apiRequest(`/api/items/${id}`, { method: 'DELETE' }, token);
          loadItems();
        },
      },
    ]);
  }

  async function logout() {
    await clearAuth();
    navigation.replace('Login');
  }

  function openSmsSettings() {
    navigation.navigate('SmsPermission');
  }

  // ----------------- UI -----------------

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <Text style={styles.title}>Inventory</Text>

        <View style={styles.headerButtons}>
          <Pressable style={styles.smallButton} onPress={openSmsSettings}>
            <Text style={styles.smallButtonText}>SMS</Text>
          </Pressable>
          <Pressable style={styles.smallButton} onPress={logout}>
            <Text style={styles.smallButtonText}>Logout</Text>
          </Pressable>
        </View>
      </View>

      {/* ADD BUTTON */}
      <Pressable style={styles.addButton} onPress={startAdd}>
        <Text style={styles.addButtonText}>+ Add Item</Text>
      </Pressable>

      {/* LIST */}
      <FlatList
        data={items}
        keyExtractor={(item) => item.id.toString()}
        refreshing={loading}
        onRefresh={loadItems}
        renderItem={({ item }) => (
          <Pressable onPress={() => startEdit(item)} style={styles.card}>
            <Text style={styles.itemTitle}>{item.name}</Text>
            <Text style={styles.itemText}>{item.description || 'No description'}</Text>
            <Text style={styles.itemText}>Qty: {item.quantity}</Text>

            <Pressable style={styles.deleteButton} onPress={() => deleteItem(item.id)}>
              <Text style={styles.deleteText}>Delete</Text>
            </Pressable>
          </Pressable>
        )}
      />

      {/* MODAL */}
      <Modal visible={showForm} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>
              {editingItem ? 'Edit Item' : 'Add Item'}
            </Text>

            <TextInput
              style={styles.input}
              placeholder="Name"
              placeholderTextColor={colors.hint_text}
              value={tempName}
              onChangeText={setTempName}
            />
            <TextInput
              style={styles.input}
              placeholder="Quantity"
              placeholderTextColor={colors.hint_text}
              value={String(tempQty)}
              keyboardType="numeric"
              onChangeText={(v) => setTempQty(Number(v))}
            />
            <TextInput
              style={styles.input}
              placeholder="Description"
              placeholderTextColor={colors.hint_text}
              value={tempDescription}
              onChangeText={setTempDescription}
            />

            <Pressable style={styles.primaryButton} onPress={saveItem}>
              <Text style={styles.primaryButtonText}>
                {editingItem ? 'Save Changes' : 'Add Item'}
              </Text>
            </Pressable>

            <Pressable style={styles.secondaryButton} onPress={() => setShowForm(false)}>
              <Text style={styles.secondaryButtonText}>Cancel</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: 16,
  },

  // HEADER
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    color: colors.white,
    fontSize: 22,
    fontWeight: 'bold',
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  smallButton: {
    backgroundColor: colors.purple_500,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  smallButtonText: {
    color: colors.white,
    fontWeight: '600',
  },

  // ADD BUTTON
  addButton: {
    backgroundColor: colors.purple_200,
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    alignItems: 'center',
  },
  addButtonText: {
    color: colors.black,
    fontWeight: '700',
    fontSize: 16,
  },

  // ITEM CARD
  card: {
    backgroundColor: colors.surface,
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
  },
  itemTitle: {
    color: colors.white,
    fontSize: 18,
    fontWeight: '600',
  },
  itemText: {
    color: colors.secondary_text,
    marginTop: 4,
  },

  deleteButton: {
    marginTop: 10,
    backgroundColor: colors.error_red,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  deleteText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: 'bold',
  },

  // MODAL
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    padding: 24,
  },
  modalCard: {
    backgroundColor: colors.surface,
    borderRadius: 10,
    padding: 20,
  },
  modalTitle: {
    color: colors.white,
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  input: {
    backgroundColor: colors.gray_light,
    color: colors.white,
    padding: 10,
    borderRadius: 8,
    marginBottom: 12,
  },

  primaryButton: {
    backgroundColor: colors.purple_200,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
  },
  primaryButtonText: {
    color: colors.black,
    fontWeight: 'bold',
    fontSize: 16,
  },
  secondaryButton: {
    padding: 10,
    borderColor: colors.purple_200,
    borderWidth: 2,
    borderRadius: 8,
    alignItems: 'center',
  },
  secondaryButtonText: {
    color: colors.purple_200,
    fontWeight: 'bold',
    fontSize: 16,
  },
});


