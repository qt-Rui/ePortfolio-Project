// src/screens/LoginScreen.tsx
import React, { useState } from 'react';
import {
  View, Text, TextInput, Pressable, Alert, StyleSheet
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../App';
import { apiRequest } from '../api';
import { saveAuth } from '../storage';
import { colors } from '../theme';

type Props = NativeStackScreenProps<RootStackParamList, 'Login'>;

export default function LoginScreen({ navigation }: Props) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  async function handleAuth(mode: 'login' | 'register') {
    if (!username || !password) {
      Alert.alert("Error", "Enter username and password");
      return;
    }

    try {
      const path = mode === 'login' ? '/api/auth/login' : '/api/auth/register';
      const res = await apiRequest(path, {
        method: "POST",
        body: JSON.stringify({ username, password })
      });

      await saveAuth(res.token, res.user.username);
      navigation.replace("Inventory");
    } catch (err: any) {
      Alert.alert("Error", err.message ?? "Request failed");
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Inventory Login</Text>

      <TextInput
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
        placeholderTextColor={colors.hint_text}
        style={styles.input}
      />

      <TextInput
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
        placeholderTextColor={colors.hint_text}
        style={styles.input}
      />

      <Pressable style={styles.primaryButton} onPress={() => handleAuth('login')}>
        <Text style={styles.primaryButtonText}>Login</Text>
      </Pressable>

      <Pressable style={styles.secondaryButton} onPress={() => handleAuth('register')}>
        <Text style={styles.secondaryButtonText}>Create Account</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 24, justifyContent: 'center' },
  title: { color: colors.white, fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginBottom: 32 },
  input: { backgroundColor: colors.surface, color: 'white', padding: 12, borderRadius: 8, marginBottom: 16 },
  primaryButton: { backgroundColor: colors.purple_200, padding: 14, borderRadius: 8, marginBottom: 12, alignItems: 'center' },
  primaryButtonText: { color: colors.black, fontSize: 16, fontWeight: 'bold' },
  secondaryButton: { padding: 14, borderRadius: 8, borderColor: colors.purple_200, borderWidth: 2, alignItems: 'center' },
  secondaryButtonText: { color: colors.purple_200, fontSize: 16, fontWeight: 'bold' },
});
