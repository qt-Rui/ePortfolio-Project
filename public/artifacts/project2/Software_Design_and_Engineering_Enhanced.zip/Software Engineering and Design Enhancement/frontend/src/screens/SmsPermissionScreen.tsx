// src/screens/SmsPermissionScreen.tsx
import React from 'react';
import { View, Text, Pressable, StyleSheet, Alert } from 'react-native';
import { setSmsEnabled } from '../storage';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../App';
import { colors } from '../theme';

type Props = NativeStackScreenProps<RootStackParamList, 'SmsPermission'>;

export default function SmsPermissionScreen({ navigation }: Props) {

  async function enableSms() {
    await setSmsEnabled(true);
    Alert.alert("Enabled", "SMS alerts enabled!");
    navigation.goBack();
  }

  async function disableSms() {
    await setSmsEnabled(false);
    Alert.alert("Disabled", "SMS alerts disabled.");
    navigation.goBack();
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>SMS Notifications</Text>

      <Pressable style={styles.button} onPress={enableSms}>
        <Text style={styles.buttonText}>Enable SMS Alerts</Text>
      </Pressable>

      <Pressable style={styles.button} onPress={disableSms}>
        <Text style={styles.buttonText}>Disable SMS Alerts</Text>
      </Pressable>

      <Pressable style={styles.secondaryButton} onPress={() => navigation.goBack()}>
        <Text style={styles.secondaryText}>Back</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 24, justifyContent: 'center' },
  title: { color: colors.white, fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginBottom: 24 },
  button: { backgroundColor: colors.purple_200, padding: 14, borderRadius: 8, marginBottom: 16 },
  buttonText: { color: colors.black, fontWeight: 'bold', textAlign: 'center' },
  secondaryButton: { padding: 12, borderRadius: 8, borderWidth: 2, borderColor: colors.purple_200, marginTop: 20 },
  secondaryText: { color: colors.purple_200, textAlign: 'center' },
});
