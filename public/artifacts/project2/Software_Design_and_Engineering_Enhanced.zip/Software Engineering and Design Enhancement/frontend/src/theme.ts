// inventory-app/src/theme.ts
export const colors = {
  purple_200: '#BB86FC',
  purple_500: '#6200EE',
  purple_700: '#3700B3',

  teal_200: '#03DAC5',
  teal_700: '#018786',

  black: '#000000',
  white: '#FFFFFF',

  background: '#121212',   // dark but readable
  surface: '#1E1E1E',      // slightly lighter than background

  primary_text: '#FFFFFF',
  secondary_text: '#CCCCCC',
  hint_text: '#999999',

  error_red: '#CF6679',
  success_green: '#4CAF50',

  gray_light: '#2C2C2C',
  gray_medium: '#666666',
  gray_dark: '#999999',
};
