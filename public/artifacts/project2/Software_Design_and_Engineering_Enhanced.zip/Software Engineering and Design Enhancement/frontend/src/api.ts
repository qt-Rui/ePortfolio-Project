// src/api.ts
import { Platform } from 'react-native';

let HOST = 'http://localhost:3000';

// For Android emulator
if (Platform.OS === 'android') {
  HOST = 'http://10.0.2.2:3000';
}

// For iOS simulator
if (Platform.OS === 'ios') {
  HOST = 'http://localhost:3000';
}

export const API_BASE_URL = HOST;

export async function apiRequest(
  path: string,
  options: RequestInit = {},
  token?: string | null
) {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const url = `${API_BASE_URL}${path}`;
  console.log(`API Request → ${options.method || 'GET'} ${url}`);

  try {
    const response = await fetch(url, {
      ...options,
      headers,
    });

    console.log(`Response status: ${response.status}`);

    if (!response.ok) {
      let errorMessage = `Request failed: ${response.status}`;
      
      try {
        const errorData = await response.json();
        errorMessage = errorData.error || errorMessage;
      } catch {
        // Response is not JSON
        const text = await response.text();
        errorMessage = text || errorMessage;
      }
      
      throw new Error(errorMessage);
    }

    // Try to parse JSON response
    try {
      const data = await response.json();
      return data;
    } catch (error) {
      console.warn('Response was not JSON or was empty');
      return null;
    }
  } catch (error: any) {
    console.error('Network error:', error);
    throw new Error(error.message || 'Network request failed');
  }
}