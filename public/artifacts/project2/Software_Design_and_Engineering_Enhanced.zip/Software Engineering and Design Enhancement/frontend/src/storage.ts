// inventory-app/src/storage.ts
import AsyncStorage from '@react-native-async-storage/async-storage';

const TOKEN_KEY = 'authToken';
const USERNAME_KEY = 'username';
const SMS_ASKED_KEY = 'hasAskedSmsPermission';
const SMS_ENABLED_KEY = 'smsEnabled';

export async function saveAuth(token: string, username: string) {
  await AsyncStorage.multiSet([
    [TOKEN_KEY, token],
    [USERNAME_KEY, username],
  ]);
}

export async function getAuth() {
  const [[, token], [, username]] = await AsyncStorage.multiGet([
    TOKEN_KEY,
    USERNAME_KEY,
  ]);
  return { token, username };
}

export async function clearAuth() {
  await AsyncStorage.multiRemove([TOKEN_KEY, USERNAME_KEY]);
}

export async function setHasAskedSmsPermission(value: boolean) {
  await AsyncStorage.setItem(SMS_ASKED_KEY, value ? '1' : '0');
}

export async function getHasAskedSmsPermission() {
  const v = await AsyncStorage.getItem(SMS_ASKED_KEY);
  return v === '1';
}

export async function setSmsEnabled(value: boolean) {
  await AsyncStorage.setItem(SMS_ENABLED_KEY, value ? '1' : '0');
}

export async function getSmsEnabled() {
  const v = await AsyncStorage.getItem(SMS_ENABLED_KEY);
  return v === '1';
}
