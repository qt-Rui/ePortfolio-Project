package com.example.cs360project2new;

public class Item {
    private int id;
    private String name;
    private String details;
    private String date;
    private int quantity;

    public Item() {}

    public Item(String name, String details, String date, int quantity) {
        this.name = name;
        this.details = details;
        this.date = date;
        this.quantity = quantity;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getDetails() {
        return details;
    }
    public void setDetails(String details) {
        this.details = details;
    }

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
}
