package com.example.cs360project2new;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "InventoryManager.db";
    private static final int DB_VERSION = 1;

    // User attributes
    private static final String TABLE_USERS = "users";
    private static final String USER_ID = "id";
    private static final String USER_USERNAME = "username";
    private static final String USER_PASSWORD = "password";

    // Item attributes
    private static final String TABLE_ITEMS = "items";
    private static final String ITEM_ID = "id";
    private static final String ITEM_NAME = "name";
    private static final String ITEM_DETAILS = "details";
    private static final String ITEM_QUANTITY="quantity";
    private static final String ITEM_DATE = "date_obtained";
    private static final String ITEM_CREATOR = "user_id_fk";

    // SQLiteOpenHelper initialization
    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Create tables for users and inventory items
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = " CREATE TABLE " + TABLE_USERS + "(" + USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + USER_USERNAME + "  TEXT UNIQUE, " + USER_PASSWORD + " TEXT" + ")";
        db.execSQL(createUsers);

        String createItemsTable = " CREATE TABLE " + TABLE_ITEMS + "(" + ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + ITEM_NAME + " TEXT, " + ITEM_DETAILS + " TEXT, " + ITEM_QUANTITY + " INTEGER DEFAULT 0, " + ITEM_DATE + " TEXT, " + ITEM_CREATOR + " INTEGER" + ")";
        db.execSQL(createItemsTable);
    }

    // Handle upgrades. Drop and recreate table
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // Add new user to database
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USER_USERNAME, username);
        values.put(USER_PASSWORD, password);
        long id = db.insert(TABLE_USERS, null, values);
        db.close();
        return id != -1;
    }

    // Make sure username and password are valid
    public boolean checkUserCredentials(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {USER_ID};
        String userSelection = USER_USERNAME + " = ? AND " + USER_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, userSelection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        return count > 0;
    }

    // Check if username exists
    public boolean usernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {USER_ID};
        String userSelection = USER_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_USERS, columns, userSelection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return  count > 0;
    }

    // Return database ID for given username
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {USER_ID};
        String userSelection = USER_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_USERS, columns, userSelection, selectionArgs, null, null, null);
        int userId = -1;

        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndexOrThrow(USER_ID));
        }

        cursor.close();
        db.close();

        return userId;
    }

    // Add item to database
    public boolean addItem(String itemName, String itemDetails, String itemDate, int itemQuantity, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ITEM_NAME, itemName);
        values.put(ITEM_DETAILS, itemDetails);
        values.put(ITEM_DATE, itemDate);
        values.put(ITEM_QUANTITY, itemQuantity);
        values.put(ITEM_CREATOR, userId);

        long result = db.insert(TABLE_ITEMS, null, values);
        db.close();
        return result != -1;
    }

    // Retrieve all items created by user
    public List<Item> getAllItems(int userId) {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {
                ITEM_ID,
                ITEM_NAME,
                ITEM_DETAILS,
                ITEM_QUANTITY,
                ITEM_DATE
        };

        String selection = ITEM_CREATOR + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        Cursor cursor = db.query(TABLE_ITEMS, columns, selection, selectionArgs, null, null, ITEM_NAME + " ASC");

        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setId(cursor.getInt(cursor.getColumnIndexOrThrow(ITEM_ID)));
                item.setName(cursor.getString(cursor.getColumnIndexOrThrow(ITEM_NAME)));
                item.setDetails(cursor.getString(cursor.getColumnIndexOrThrow(ITEM_DETAILS)));
                item.setQuantity(cursor.getInt(cursor.getColumnIndexOrThrow(ITEM_QUANTITY)));
                item.setDate(cursor.getString(cursor.getColumnIndexOrThrow(ITEM_DATE)));
                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return itemList;
    }

    // Retrieve item by ID
    public Item getItemById(int itemId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {
                ITEM_ID,
                ITEM_NAME,
                ITEM_DETAILS,
                ITEM_DATE
        };

        String selection = ITEM_ID + " = ?";
        String[] selectionArgs = {String.valueOf(itemId)};

        Cursor cursor = db.query(TABLE_ITEMS, columns, selection, selectionArgs, null, null, null);

        Item item = null;
        if (cursor.moveToFirst()) {
            item = new Item();
            item.setId(cursor.getInt(cursor.getColumnIndexOrThrow(ITEM_ID)));
            item.setName(cursor.getString(cursor.getColumnIndexOrThrow(ITEM_NAME)));
            item.setDetails(cursor.getString(cursor.getColumnIndexOrThrow(ITEM_DETAILS)));
            item.setDate(cursor.getString(cursor.getColumnIndexOrThrow(ITEM_DATE)));
        }
        cursor.close();
        db.close();

        return item;
    }

    // Update already existing item
    public boolean updateItem(int itemId, String itemName, String itemDetails, String itemDate, int itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ITEM_NAME, itemName);
        values.put(ITEM_DETAILS, itemDetails);
        values.put(ITEM_DATE, itemDate);
        values.put(ITEM_QUANTITY, itemQuantity);

        String where = ITEM_ID + " = ?";
        String[] whereArgs = {String.valueOf(itemId)};

        int result = db.update(TABLE_ITEMS, values, where, whereArgs);
        db.close();

        return result > 0;
    }

    // Delete item going by ID of item
    public boolean deleteItem(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        String where = ITEM_ID + " = ?";
        String[] whereArgs = {String.valueOf(itemId)};

        int result = db.delete(TABLE_ITEMS, where, whereArgs);
        db.close();

        return result > 0;
    }

}
