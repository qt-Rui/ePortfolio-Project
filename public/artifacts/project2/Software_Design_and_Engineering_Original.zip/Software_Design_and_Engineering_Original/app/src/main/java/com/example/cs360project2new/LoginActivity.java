package com.example.cs360project2new;

import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


// Handle the user login, account creation, and staying logged in
// If user is logged in, redirect user to Sms permissions
public class LoginActivity extends AppCompatActivity {

    // The UI
    private EditText editTextUsername, editTextPassword;
    private Button buttonLogin, buttonCreateAccount;
    private TextView textViewForgotPassword;

    // For managing user accounts
    private DatabaseHelper databaseHelper;


    // save the login session
    public static final String PREFS_NAME = "LoginPrefs";
    public static final String KEY_USERNAME = "username";
    public static final String KEY_LOGGED_IN = "isLoggedIn";

    private SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login_main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initializing functions, helper, and preferences
        databaseHelper = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        checkExistingLogin();
        initializeViews();
        setupClickListeners();
    }

    // If user is logged in, skip login
    private void checkExistingLogin() {
        boolean isLoggedIn = sharedPreferences.getBoolean(KEY_LOGGED_IN, false);
        if (isLoggedIn) {
            navigateToSmsPermissionActivity();
        }
    }

    // connect components to Java
    private void initializeViews() {
        editTextUsername = findViewById(R.id.username);
        editTextPassword = findViewById(R.id.password);
        buttonLogin = findViewById(R.id.loginBtn);
        buttonCreateAccount = findViewById(R.id.createAccBtn);
        textViewForgotPassword = findViewById(R.id.forgotPass);
    }

    // Click listeners for login, account creation, forgot password
    private void setupClickListeners() {
        buttonLogin.setOnClickListener(v -> attemptLogin());

        buttonCreateAccount.setOnClickListener(v -> createNewAccount());

        textViewForgotPassword.setOnClickListener(v -> {
            Toast.makeText(LoginActivity.this, "No password recovery yet", Toast.LENGTH_SHORT).show();
        });
    }

    // Check credentials. If correct, log user in
    private void attemptLogin() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Must enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check credentials in database
        if (databaseHelper.checkUserCredentials(username, password)) {
            saveLoginSession(username);

            navigateToSmsPermissionActivity();

            Toast.makeText(this, "Successfully logged in", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Username or password is invalid", Toast.LENGTH_SHORT).show();
        }
    }

    // If username available, create account
    private void createNewAccount() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Must enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.usernameExists(username)) {
            Toast.makeText(this, "This username already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add the new user to the database
        if (databaseHelper.addUser(username, password)) {
            saveLoginSession(username);

            navigateToSmsPermissionActivity();

            Toast.makeText(this, "Account has been created!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Account creation failed", Toast.LENGTH_SHORT).show();
        }
    }

    // Login session details are saved in SharedPreferences
    private void saveLoginSession(String username) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_LOGGED_IN, true);
        editor.putString(KEY_USERNAME, username);
        editor.apply();
    }

    // Sms permission or data display directory
    private void navigateToSmsPermissionActivity() {
         SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
         boolean hasAskedPermission = prefs.getBoolean("hasAskedSmsPermission", false);

         Intent intent;
         if (!hasAskedPermission) {
             intent = new Intent(LoginActivity.this, SmsPermissionActivity.class);
         } else {
             intent = new Intent(LoginActivity.this, Activity_display.class);
         }
         startActivity(intent);
         finish();
    }
}