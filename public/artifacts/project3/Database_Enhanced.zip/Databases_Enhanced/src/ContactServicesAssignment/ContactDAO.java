package ContactServicesAssignment;

import java.sql.*;

public class ContactDAO {

	// ADD new contact to list
    public void insertContact(Contact c) throws Exception {
        String sql = "INSERT INTO contacts (contact_id, first_name, last_name, phone, address) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, c.getContactId());
            stmt.setString(2, c.getFirstName());
            stmt.setString(3, c.getLastName());
            stmt.setString(4, c.getPhone());
            stmt.setString(5, c.getAddress());
            stmt.executeUpdate();
        }
    }

    // READ a contact from the list
    public Contact getContact(String id) throws Exception {
        String sql = "SELECT * FROM contacts WHERE contact_id = ?";

        // connection and statement close automatically
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();

            if (!rs.next()) return null; // if no record found

            return new Contact(
                rs.getString("contact_id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("phone"),
                rs.getString("address")
            );
        }
    }

    // DELETE a contact from the list
    public void deleteContact(String id) throws Exception {
        String sql = "DELETE FROM contacts WHERE contact_id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id);
            stmt.executeUpdate();
        }
    }

    // UPDATE information for a contact in the list
    public void updateField(String id, String field, String value) throws Exception {
        String sql = "UPDATE contacts SET " + field + " = ? WHERE contact_id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, value);
            stmt.setString(2, id);
            stmt.executeUpdate();
        }
    }
}
