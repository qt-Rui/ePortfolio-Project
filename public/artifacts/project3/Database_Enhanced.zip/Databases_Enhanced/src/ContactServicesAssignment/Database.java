package ContactServicesAssignment;

import java.sql.Connection;
import java.sql.DriverManager;

// SSL needed for Neon
public class Database {
    private static final String URL =
        "jdbc:postgresql://ep-noisy-dream-ahk9jju9-pooler.c-3.us-east-1.aws.neon.tech/neondb" +
        "?user=neondb_owner" +
        "&password=npg_Pm7viBSgfZ4F" +
        "&sslmode=require";

    public static Connection getConnection() throws Exception {
        Class.forName("org.postgresql.Driver");
        return DriverManager.getConnection(URL);
    }
}
