package ContactServicesAssignment;

public class ContactService {

    private final ContactDAO dao = new ContactDAO();

    // add a new contact
    public void addContact(Contact contact) {
        try {
        	// check for duplicates first
            if (dao.getContact(contact.getContactId()) != null) {
                throw new IllegalArgumentException("Contact exists");
            }
            dao.insertContact(contact);
        } catch (IllegalArgumentException e) {
            throw e; 
        } catch (Exception e) { // unexpected errors
            throw new RuntimeException(e);
        }
    }


    // Remove contact from list
    public void deleteContact(String id) {
        try {
            if (dao.getContact(id) == null) {
                throw new IllegalArgumentException("Contact not found");
            }
            dao.deleteContact(id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // update a specific piece of information from a contact
    public void updateFirstName(String id, String newValue) {
        Contact existing = get(id);
        existing.setFirstName(newValue);
        update(id, "first_name", newValue);
    }

    public void updateLastName(String id, String newValue) {
        Contact existing = get(id);
        existing.setLastName(newValue);
        update(id, "last_name", newValue);
    }

    public void updatePhone(String id, String newValue) {
        Contact existing = get(id);
        existing.setPhone(newValue);
        update(id, "phone", newValue);
    }

    public void updateAddress(String id, String newValue) {
        Contact existing = get(id);
        existing.setAddress(newValue);
        update(id, "address", newValue);
    }

    // retrieve contact but throw error if not found
    private Contact get(String id) {
        try {
            Contact c = dao.getContact(id);
            if (c == null) throw new IllegalArgumentException("Contact not found");
            return c;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // pushes update field to database
    private void update(String id, String field, String value) {
        try {
            dao.updateField(id, field, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
