package ContactServicesAssignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    @DisplayName("Test contact creation")
    public void testCorrectContactCreation() {
        Contact contact = new Contact("1234", "Johnny", "Silverhand", "1234567890", "1234 Street");
        assertEquals("1234", contact.getContactId());
        assertEquals("Johnny", contact.getFirstName());
        assertEquals("Silverhand", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("1234 Street", contact.getAddress());
    }
    
    @Test
    @DisplayName("Does not accept NULL as any value")
    public void doesNotTakeNULL() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Johnny", "Silverhand", "1234567890", "1234 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234", null, "Silverhand", "1234567890", "1234 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234", "Johnny", null, "1234567890", "1234 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234", "Johnny", "Silverhand", null, "1234 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234", "Johnny", "Silverhand", "1234567890", null));
    }
    
    @Test
    @DisplayName("Does not take long values")
    public void doesNotTakeLongValues() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901234567", "Johnny", "Silverhand", "1234567890", "1234 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234", "Johnny Johnson Johnboy", "Silverhand", "1234567890", "1234 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234", "Johnny", "Silverhand SilverFinger", "1234567890", "1234 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234", "Johnny", "Silverhand", "12345", "1234 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234", "Johnny", "Silverhand", "1234567890", "Very very very very long street name"));
    }
    
    @Test
    @DisplayName("Test setters with valid values, make sure they are correct values")
    public void testSetters() {
        Contact contact = new Contact("1234", "Johnny", "Silverhand", "1234567890", "1234 Street");
        
        contact.setFirstName("Johnny");
        contact.setLastName("SilverHand");
        contact.setPhone("1234567890");
        contact.setAddress("1234 Street");
        
        assertEquals("Johnny", contact.getFirstName());
        assertEquals("SilverHand", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("1234 Street", contact.getAddress());
    }
    
    @Test
    @DisplayName("Test setters with invalid values")
    public void testInvalidSetters() {
        Contact contact = new Contact("1234", "Johnny", "Silverhand", "1234567890", "1234 Street");
        
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("Johnny John John"));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("Silverhand SilverFinger"));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("12345"));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("very very very very long address name"));
    }
}
