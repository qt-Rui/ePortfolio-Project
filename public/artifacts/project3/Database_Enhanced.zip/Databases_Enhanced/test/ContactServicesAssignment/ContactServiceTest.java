package ContactServicesAssignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;

class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setUp() throws Exception {
        // Reset the database before each test
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM contacts")) {
            stmt.executeUpdate();
        }

        service = new ContactService();

        // Add a fresh base contact
        Contact contact = new Contact("1234", "Johnny", "Silverhand", "1234567890", "1234 Street");
        service.addContact(contact);
    }

    @Test
    @DisplayName("Add a contact")
    public void testAddContact() {
        Contact newContact = new Contact("5678", "Nico", "Belic", "0987654321", "5678 Street");
        service.addContact(newContact);
        // Adding the same contact again fails
        assertThrows(IllegalArgumentException.class, () -> service.addContact(newContact));
    }

    @Test
    @DisplayName("Update first name")
    public void testUpdateFirstName() {
        service.updateFirstName("1234", "Leon");
        Contact updated = fetch("1234");
        assertEquals("Leon", updated.getFirstName());
    }

    @Test
    @DisplayName("Update last name")
    public void testUpdateLastName() {
        service.updateLastName("1234", "Kennedy");
        Contact updated = fetch("1234");
        assertEquals("Kennedy", updated.getLastName());
    }

    @Test
    @DisplayName("Update phone number")
    public void testUpdatePhone() {
        service.updatePhone("1234", "0987654321");
        Contact updated = fetch("1234");
        assertEquals("0987654321", updated.getPhone());
    }

    @Test
    @DisplayName("Update address")
    public void testUpdateAddress() {
        service.updateAddress("1234", "123 Street");
        Contact updated = fetch("1234");
        assertEquals("123 Street", updated.getAddress());
    }

    @Test
    @DisplayName("Invalid update test")
    public void testInvalidUpdate() {
        // Invalid phone
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("1234", "123456"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("1234", null));

        // Invalid first name
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("1234", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("1234", "Leeeeeeeeeeeeeon"));

        // Invalid last name
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("1234", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("1234", "Kennnnnnnnnnnedy"));

        // Invalid address
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("1234", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("1234", "1234 Streeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeet"));
    }

    // Helper to retrieve contact directly from the database
    private Contact fetch(String id) {
        try {
            return new ContactDAO().getContact(id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
