package ContactServicesAssignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
	private ContactService service;
	private Contact contact;
	
	@BeforeEach
	public void setUp() {
		service = new ContactService();
		contact = new Contact("1234", "Johnny", "Silverhand", "1234567890", "1234 Street");
		service.addContact(contact);
	}

	@Test
	@DisplayName("Add a contact")
	public void testAddContact() {
		Contact newContact = new Contact("5678", "Nico", "Belic", "0987654321", "5678 Street");
		service.addContact(newContact);
		assertThrows(IllegalArgumentException.class, () -> service.addContact(newContact));
	}
	
	@Test
	@DisplayName("update first name")
	public void testUpdateFirstName() {
		service.updateFirstName("1234", "Leon");
		assertEquals("Leon", contact.getFirstName());
	}
	
	@Test
	@DisplayName("update last name")
	public void testUpdateLastName() {
		service.updateLastName("1234", "Kennedy");
		assertEquals("Kennedy", contact.getLastName());
	}
	
	@Test
	@DisplayName("update phone number")
	public void testUpdatePhone() {
		service.updatePhone("1234", "0987654321");
		assertEquals("0987654321", contact.getPhone());
	}
	
	@Test
	@DisplayName("update address")
	public void testUpdateAddress() {
		service.updateAddress("1234", "123 Street");
		assertEquals("123 Street", contact.getAddress());
	}
	
	@Test
	@DisplayName("Invalid update test")
	public void testInvalidUpdate() {
		assertThrows(IllegalArgumentException.class, () -> service.updatePhone("1234", "123456"));
		assertThrows(IllegalArgumentException.class, () -> service.updatePhone("1234", null));
		assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("1234", null));
		assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("1234", "Leeeeeeeeeeeeeon"));
		assertThrows(IllegalArgumentException.class, () -> service.updateLastName("1234", null));
		assertThrows(IllegalArgumentException.class, () -> service.updateLastName("1234", "Kennnnnnnnnnnedy"));
		assertThrows(IllegalArgumentException.class, () -> service.updateAddress("1234", null));
		assertThrows(IllegalArgumentException.class, () -> service.updateAddress("1234", "1234 Streeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeet"));
	}
}
